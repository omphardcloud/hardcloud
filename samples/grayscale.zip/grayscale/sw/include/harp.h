#ifndef __HARP_H__
#define __HARP_H__

#define HARP    9002
#define HARPSIM 9006

#endif // __HARP_H__
